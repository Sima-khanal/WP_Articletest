   jQuery(document).ready(function($) {
  if ($("#lightSlider").length) {
    $("#lightSlider").lightSlider({
      item: 1, 
      slideMove: 1, 
      auto: true, 
      loop: true, 
      pauseOnHover: true, 
      controls: true, 
      pager: false, 
      speed: 1000, // Smooth transition speed
      pause: 4000, // Delay between slides
      adaptiveHeight: true 
    });
  }
});

document.addEventListener("DOMContentLoaded", function() {
    const carousel = document.querySelector(".featured-carousel");
    const slides = document.querySelectorAll(".featured-slide");
    const prevBtn = document.querySelector(".prev-btn");
    const nextBtn = document.querySelector(".next-btn");

    let index = 0;
    let totalSlides = slides.length; 

    function showSlide(i) {
        if (i < 0) {
            index = totalSlides - 1;
        } else if (i >= totalSlides) {
            index = 0;
        } else {
            index = i;
        }
        let translateValue = -index * 100;
        carousel.style.transform = `translateX(${translateValue}%)`;
    }

    nextBtn.addEventListener("click", function() {
        showSlide(index + 1);
    });

    prevBtn.addEventListener("click", function() {
        showSlide(index - 1);
    });
});
