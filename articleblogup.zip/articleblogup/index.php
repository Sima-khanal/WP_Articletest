<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package articleBlogup
 */

get_header();
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightslider/1.1.6/css/lightslider.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightslider/1.1.6/js/lightslider.min.js"></script>

<main id="primary" class="site-main">
   <?php if (is_home()) : ?>
   <?php else : ?>
   <?php endif; ?>


<div class="content-wrapper">
<section id="banner-slider">
  <form method="GET" id="category-filter">
    <label for="category">Filter by Category:</label>
    <?php
    $categories = get_categories();
    echo '<select name="category" id="category" onchange="this.form.submit()">';
    echo '<option value="">All Categories</option>';
    foreach ($categories as $category) {
        $selected = (isset($_GET['category']) && $_GET['category'] == $category->slug) ? 'selected' : '';
        echo '<option value="' . esc_attr($category->slug) . '" ' . esc_attr($selected) . '>' . esc_html($category->name) . '</option>';
    }
    echo '</select>';
    ?>
  </form>

  <ul id="lightSlider">
    <?php
    $category_filter = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : '';
    $banner_query = new WP_Query(array(
        'post_type'      => 'post',
        'posts_per_page' => 5,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'category_name'  => $category_filter 
    ));

    if ($banner_query->have_posts()) :
        while ($banner_query->have_posts()) : $banner_query->the_post(); ?>
            <li class="slider-item" style="background-image: url('<?php echo get_the_post_thumbnail_url(); ?>');">
              <div class="overlay">
                <div class="category">
                  <span><?php the_category(', '); ?></span>
                </div>
                <div class="header">
                  <h2><?php the_title(); ?></h2>
                </div>
                <div class="description">
                  <p><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>
                </div>
                <a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>
              </div>
            </li>
        <?php endwhile; 
        wp_reset_postdata(); 
    else : ?>
        <p>No posts found for the banner slider.</p>
    <?php endif; ?>
  </ul>
</section>

  <section id="featured-slider">
    <h2> Featured Items</h2>
    <form method="POST" id="category-filter">
        <label for="category">Filter by Category:</label>
        <?php
        $categories = get_categories();
        echo '<select name="category" id="category" onchange="this.form.submit()">';
        echo '<option value="">All Categories</option>';
        foreach ($categories as $category) {
            $selected = (isset($_POST['category']) && $_POST['category'] == $category->slug) ? 'selected' : '';
            echo '<option value="' . esc_attr($category->slug) . '" ' . esc_attr($selected) . '>' . esc_html($category->name) . '</option>';
        }
        echo '</select>';
        ?>
    </form>

    <?php
    $category_filter = isset($_POST['category']) ? sanitize_text_field($_POST['category']) : '';
    $args = array(
        'post_type'      => 'post',
        'posts_per_page' => -1,
        'orderby'        => 'rand',
        'category_name'  => $category_filter
    );

    $query = new WP_Query($args);
    $total_posts = $query->post_count;
    ?>

    <div class="featured-container">
        <button class="prev-btn">&#10094;</button>
        <div class="featured-carousel-wrapper">
            <div class="featured-carousel">
                <?php if ($query->have_posts()) :
                    $count = 0;
                    $total_slides = ceil($total_posts / 3);
                     ?>
                    <?php for ($i = 0; $i < $total_slides; $i++) : ?>
                        <div class="featured-slide">
                            <?php for ($j = 0; $j < 3; $j++) :
                                if ($query->have_posts()) : $query->the_post();
                                    $bgImage = get_the_post_thumbnail_url(get_the_ID(), 'large');
                                    ?>
                                    <div class="featured-item" style="background-image: url('<?php echo esc_url($bgImage); ?>');">
                                        <div class="overlay"></div>
                                        <div class="content">
                                            <span class="category"><?php the_category(', '); ?></span>
                                            <h3><?php the_title(); ?></h3>
                                            <p><?php echo wp_trim_words(get_the_content(), 15, '...'); ?></p>
                                            <a href="<?php the_permalink(); ?>" class="read-more">Read More</a>
                                        </div>
                                    </div>
                                <?php endif;
                            endfor; ?>
                        </div>
                    <?php endfor;
                    wp_reset_postdata(); ?>
                <?php else : ?>
                    <p>No featured posts found.</p>
                <?php endif; ?>
            </div>
        </div>
      <button class="next-btn">&#10095;</button>
    </div>
</section>

<!-- Latest Posts Section -->
<section id="latest-posts">
  <h2>Latest Posts</h2>

  <div class="posts-container">
    
    <?php
      $args = array(
        'post_status'    => 'publish', 
        'orderby'        => 'date',    
        'order'          => 'DESC',    
        'posts_per_page' => -1,        
      );

      $latest_posts = new WP_Query($args);
      if ($latest_posts->have_posts()) :
        while ($latest_posts->have_posts()) : $latest_posts->the_post();
    ?>
    <div class="post-item">
      <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>">
      <div class="post-meta">
        <span class="category"><?php the_category(', '); ?></span> 
      </div>
      <h3><?php the_title(); ?></h3>
      <p><?php echo wp_trim_words(get_the_content(), 15, '...'); ?></p>
      <a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>
    </div>
    <?php endwhile; endif; wp_reset_postdata(); ?>
  </div>
</section>

<section class="portfolio">
    <h2><?php echo esc_html(get_theme_mod('articleblogup_portfolio_title', 'Our Portfolio')); ?></h2>
    
    <div class="portfolio-items">
        <?php
        $category_id = get_theme_mod('articleblogup_portfolio_category', '');
        $post_count = get_theme_mod('articleblogup_portfolio_post_count', 3);

        $args = array(
            'post_type'      => 'post',
            'cat'            => $category_id,
            'posts_per_page' => $post_count,
        );

        $query = new WP_Query($args);

        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post(); ?>
                <div class="portfolio-item">
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <?php the_post_thumbnail('medium'); ?>
                    <p><?php the_excerpt(); ?></p>
                </div>
            <?php endwhile;
            wp_reset_postdata();
        else :
            echo '<p>No portfolio items found.</p>';
        endif;
        ?>
    </div>
</section>
</div>

	</main><!-- #main -->
 
<?php
get_sidebar();
get_footer();
