<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package articleBlogup
 */
if (is_active_sidebar('sidebar-1')) {
    dynamic_sidebar('sidebar-1');
}

?>

<aside id="secondary" class="widget-area">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
	
	<div class="sidebar">
    <h3>About This Theme</h3>
    <p><?php echo esc_html(get_theme_mod('theme_description_text', 'Default theme description.')); ?></p>

    <h4>Follow Us</h4>
    <ul>
        <?php if (get_theme_mod('facebook_url')): ?>
            <li><a href="<?php echo esc_url(get_theme_mod('facebook_url')); ?>" target="_blank">Facebook</a></li>
        <?php endif; ?>
        <?php if (get_theme_mod('twitter_url')): ?>
            <li><a href="<?php echo esc_url(get_theme_mod('twitter_url')); ?>" target="_blank">Twitter</a></li>
        <?php endif; ?>
        <?php if (get_theme_mod('instagram_url')): ?>
            <li><a href="<?php echo esc_url(get_theme_mod('instagram_url')); ?>" target="_blank">Instagram</a></li>
        <?php endif; ?>
    </ul>
</div>
</aside><!-- #secondary -->
