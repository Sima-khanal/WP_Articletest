<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package articleBlogup
 */

?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php bloginfo( 'name' ); ?> | <?php bloginfo( 'description' ); ?></title>
    <?php wp_head(); ?>
    <!-- LightSlider CSS -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/lightslider@1.1.6/dist/css/lightslider.min.css" />
	<!-- LightSlider JS -->
	<script src="https://cdn.jsdelivr.net/npm/lightslider@1.1.6/dist/js/lightslider.min.js"></script>

</head>
<body <?php body_class(); ?>>

<header>
	
    <div class="logo">
        <?php
        if ( has_custom_logo() ) {
            the_custom_logo();
        } else {
            echo '<h1>' . get_bloginfo( 'name' ) . '</h1>';
        }
        ?>
    </div>

    <!-- Navigation Bar -->
    <nav class="main-navigation">
        <?php
        wp_nav_menu( array(
            'theme_location' => 'primary', // This refers to the location for your menu
            'menu_class' => 'navbar', // Assigning a class for the navbar
        ) );
        ?>
    </nav>

    <!-- Search Bar -->
    <div class="search-bar">
        <?php get_search_form(); ?>
    </div>
</header>

