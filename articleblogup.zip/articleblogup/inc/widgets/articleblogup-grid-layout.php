<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Check if class exists before defining
if (!class_exists('ArticleBlogUp_Grid_Layout')) {
    class ArticleBlogUp_Grid_Layout extends WP_Widget {

        public function __construct() {
            $widget_ops = array( 
                'classname'   => 'articleblogup_grid_layout',
                'description' => __('Display posts from a selected category in a grid view.', 'articleblogup')
            );
            parent::__construct('articleblogup_grid_layout', __('ArticleBlogUp: Grid Items', 'articleblogup'), $widget_ops);
        }

        /**
         * Widget Form Fields
         */
        private function widget_fields() {
            // Fetch categories dynamically
            $categories = get_categories(array('hide_empty' => 0));
            $category_options = array(0 => __('Select Category', 'articleblogup'));
            foreach ($categories as $category) {
                $category_options[$category->term_id] = $category->name;
            }

            return array(
                'section_title' => array(
                    'name'  => 'section_title',
                    'title' => __('Section Title', 'articleblogup'),
                    'type'  => 'text'
                ),
                'section_info' => array(
                    'name'  => 'section_info',
                    'title' => __('Section Info', 'articleblogup'),
                    'type'  => 'textarea'
                ),
                'section_cat' => array(
                    'name'    => 'section_cat',
                    'title'   => __('Section Category', 'articleblogup'),
                    'type'    => 'select',
                    'options' => $category_options
                ),
                'section_post_count' => array(
                    'name'    => 'section_post_count',
                    'title'   => __('Number of Posts', 'articleblogup'),
                    'type'    => 'number',
                    'default' => 3
                ),
            );
        }

        /**
         * Display widget frontend
         */
        public function widget($args, $instance) {
            extract($args);

            if (empty($instance)) return;

            $title        = !empty($instance['section_title']) ? esc_html($instance['section_title']) : '';
            $info         = !empty($instance['section_info']) ? wp_kses_post($instance['section_info']) : '';
            $category_id  = !empty($instance['section_cat']) ? absint($instance['section_cat']) : 0;
            $post_count   = !empty($instance['section_post_count']) ? absint($instance['section_post_count']) : 3;

            if ($category_id === 0) return;

            // Define title section class
            $title_class = (!empty($title) || !empty($info)) ? 'has-title' : 'no-title';

            // Fetch posts
            $query_args = array(
                'post_type'      => 'post',
                'cat'            => $category_id,
                'posts_per_page' => $post_count
            );
            $query = new WP_Query($query_args);

            echo $before_widget;
            ?>
            <div class="section-wrapper articleblogup-widget-wrapper">
                <div class="mt-container">
                    <div class="section-title-wrapper <?php echo esc_attr($title_class); ?> clearfix">
                        <?php if ($title) echo $before_title . $title . $after_title; ?>
                        <?php if ($info) echo '<span class="section-info">' . $info . '</span>'; ?>
                    </div>

                    <div class="grid-items-wrapper mt-column-wrapper">
                        <?php if ($query->have_posts()) : ?>
                            <?php while ($query->have_posts()) : $query->the_post(); ?>
                                <div class="single-post-wrapper mt-column-3">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <div class="img-holder">
                                            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                                                <?php the_post_thumbnail('large'); ?>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <h3 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                    <?php the_excerpt(); ?>
                                </div>
                            <?php endwhile; ?>
                            <?php wp_reset_postdata(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php
            echo $after_widget;
        }

        /**
         * Sanitize widget values as they are saved
         */
        public function update($new_instance, $old_instance) {
            $instance = $old_instance;
            foreach ($this->widget_fields() as $field) {
                $name = $field['name'];
                switch ($field['type']) {
                    case 'text':
                        $instance[$name] = sanitize_text_field($new_instance[$name]);
                        break;
                    case 'textarea':
                        $instance[$name] = sanitize_textarea_field($new_instance[$name]);
                        break;
                    case 'select':
                    case 'number':
                        $instance[$name] = absint($new_instance[$name]);
                        break;
                }
            }
            return $instance;
        }

        /**
         * Widget backend form
         */
        public function form($instance) {
            foreach ($this->widget_fields() as $field) {
                $name = esc_attr($this->get_field_name($field['name']));
                $id   = esc_attr($this->get_field_id($field['name']));
                $value = isset($instance[$field['name']]) ? esc_attr($instance[$field['name']]) : (isset($field['default']) ? $field['default'] : '');

                echo '<p>';
                echo '<label for="' . $id . '">' . esc_html($field['title']) . ':</label>';

                switch ($field['type']) {
                    case 'text':
                        echo '<input class="widefat" id="' . $id . '" name="' . $name . '" type="text" value="' . $value . '">';
                        break;
                    case 'textarea':
                        echo '<textarea class="widefat" id="' . $id . '" name="' . $name . '" rows="4">' . esc_textarea($value) . '</textarea>';
                        break;
                    case 'select':
                        echo '<select class="widefat" id="' . $id . '" name="' . $name . '">';
                        foreach ($field['options'] as $key => $label) {
                            echo '<option value="' . esc_attr($key) . '" ' . selected($value, $key, false) . '>' . esc_html($label) . '</option>';
                        }
                        echo '</select>';
                        break;
                    case 'number':
                        echo '<input class="widefat" id="' . $id . '" name="' . $name . '" type="number" value="' . $value . '" min="1">';
                        break;
                }

                echo '</p>';
            }
        }
    }

    /**
     * Register Widget
     */
    function register_articleblogup_grid_layout_widget() {
        register_widget('ArticleBlogUp_Grid_Layout');
    }
    add_action('widgets_init', 'register_articleblogup_grid_layout_widget');
}
?>
