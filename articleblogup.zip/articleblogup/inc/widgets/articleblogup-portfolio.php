<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Articleblogup_portfolio extends WP_Widget {
    public function __construct() {
        $widget_ops = array(
            'classname'   => 'articleblogup_portfolio',
            'description' => __('Display content as a portfolio.', 'Articleblogup')
        );
        parent::__construct('articleblogup_portfolio', __('Articleblogup: Portfolio', 'Articleblogup'), $widget_ops);
    }

    // Define Widget Form Fields
    public function form($instance) {
        $defaults = array(
            'section_title' => '',
            'section_info' => '',
            'section_category' => '',
            'section_post_count' => 5 // Default value
        );
        $instance = wp_parse_args((array) $instance, $defaults);

        $section_title = esc_textarea($instance['section_title']);
        $section_info = esc_textarea($instance['section_info']);
        $section_category = esc_attr($instance['section_category']);
        $section_post_count = absint($instance['section_post_count']); // Ensuring positive number

        // Get all categories dynamically
        $categories = get_categories();
        ?>

        <!-- Section Title -->
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('section_title')); ?>">
                <?php esc_html_e('Section Title:', 'Articleblogup'); ?>
            </label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('section_title')); ?>"
                      name="<?php echo esc_attr($this->get_field_name('section_title')); ?>" rows="1"><?php echo $section_title; ?></textarea>
        </p>

        <!-- Section Info -->
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('section_info')); ?>">
                <?php esc_html_e('Section Info:', 'Articleblogup'); ?>
            </label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('section_info')); ?>"
                      name="<?php echo esc_attr($this->get_field_name('section_info')); ?>" rows="5"><?php echo $section_info; ?></textarea>
        </p>

        <!-- Section Category (Dropdown) -->
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('section_category')); ?>">
                <?php esc_html_e('Section Category:', 'Articleblogup'); ?>
            </label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('section_category')); ?>"
                    name="<?php echo esc_attr($this->get_field_name('section_category')); ?>">
                <option value=""><?php esc_html_e('Select Category', 'Articleblogup'); ?></option>
                <?php foreach ($categories as $category) : ?>
                    <option value="<?php echo esc_attr($category->term_id); ?>" <?php selected($section_category, $category->term_id); ?>>
                        <?php echo esc_html($category->name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>

        <!-- Section Post Count (Ensure Positive Number) -->
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('section_post_count')); ?>">
                <?php esc_html_e('Post Count:', 'Articleblogup'); ?>
            </label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('section_post_count')); ?>"
                   name="<?php echo esc_attr($this->get_field_name('section_post_count')); ?>" type="number" min="1"
                   value="<?php echo $section_post_count; ?>">
        </p>
        <?php
    }

    // Update Widget Fields
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['section_title'] = (!empty($new_instance['section_title'])) ? wp_kses_post($new_instance['section_title']) : '';
        $instance['section_info'] = (!empty($new_instance['section_info'])) ? wp_kses_post($new_instance['section_info']) : '';
        $instance['section_category'] = (!empty($new_instance['section_category'])) ? sanitize_text_field($new_instance['section_category']) : '';
        $instance['section_post_count'] = (!empty($new_instance['section_post_count']) && is_numeric($new_instance['section_post_count']) && $new_instance['section_post_count'] > 0) ? absint($new_instance['section_post_count']) : 5; // Ensuring a positive number

        return $instance;
    }

    // Display Widget Content
    public function widget($args, $instance) {
        extract($args);

        if (empty($instance)) {
            return;
        }

        $Articleblogup_section_title = isset($instance['section_title']) ? $instance['section_title'] : '';
        $Articleblogup_section_info = isset($instance['section_info']) ? $instance['section_info'] : '';
        $Articleblogup_section_cat = isset($instance['section_category']) ? $instance['section_category'] : '';
        $Articleblogup_section_post_count = isset($instance['section_post_count']) ? absint($instance['section_post_count']) : 5;

        // Query Portfolio Posts
        $portfolio_query = new WP_Query(array(
            'post_type'      => 'portfolio',
            'posts_per_page' => $Articleblogup_section_post_count, // Limit results
            'cat'            => $Articleblogup_section_cat, // Filter by selected category
        ));

        echo $before_widget;
        ?>

        <div class="mt-container">
            <div class="cta-content-wrapper">
                <!-- Section Title -->
                <h2 class="section-title"><?php echo esc_html($Articleblogup_section_title); ?></h2>

                <!-- Section Info -->
                <p class="section-info"><?php echo wp_kses_post($Articleblogup_section_info); ?></p>

                <?php if ($portfolio_query->have_posts()) : ?>
                    <div class="portfolio-list">
                        <?php while ($portfolio_query->have_posts()) : $portfolio_query->the_post(); ?>
                            <div class="portfolio-item">
                                <!-- Portfolio Post Title -->
                                <h3 class="portfolio-title"><?php the_title(); ?></h3>

                                <!-- Portfolio Post Category -->
                                <p class="portfolio-category">
                                    <?php
                                    $categories = get_the_category();
                                    if (!empty($categories)) {
                                        echo esc_html($categories[0]->name); // Display first category
                                    } else {
                                        echo esc_html__('Uncategorized', 'Articleblogup'); // If no category exists
                                    }
                                    ?>
                                </p>
                            </div>
                        <?php endwhile; ?>
                    </div>

                    <!-- Total Post Count -->
                    <p class="post-count">
                        <?php printf(esc_html__('Total Posts: %d', 'Articleblogup'), $portfolio_query->post_count); ?>
                    </p>
                <?php else : ?>
                    <p class="no-posts"><?php esc_html_e('No portfolio items found.', 'Articleblogup'); ?></p>
                <?php endif; ?>
                <?php wp_reset_postdata(); ?>
            </div>
        </div>

        <?php
        echo $after_widget;
    }
}

// Register the Widget
function register_Articleblogup_portfolio() {
    register_widget('Articleblogup_portfolio');
}
add_action('widgets_init', 'register_Articleblogup_portfolio');
?>
