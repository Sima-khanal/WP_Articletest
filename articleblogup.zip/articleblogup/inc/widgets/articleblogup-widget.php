<?php
// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('articleblogup_Theme_Widget')) {
    class articleblogup_Theme_Widget extends WP_Widget {

        public function __construct() {
            parent::__construct(
                'articleblogup_theme_widget',
                __('Articleblogup Theme Widget', 'articleblogup'),
                array('description' => __('A articleblogup widget for your theme.', 'articleblogup'))
            );
        }

        public function widget($args, $instance) {
            echo $args['before_widget'];
            if (!empty($instance['title'])) {
                echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
            }
            echo '<p>' . esc_html($instance['message']) . '</p>';
            echo $args['after_widget'];
        }

        public function form($instance) {
            $title = !empty($instance['title']) ? $instance['title'] : __('New Title', 'articleblogup');
            $message = !empty($instance['message']) ? $instance['message'] : __('Hello, world!', 'articleblogup');
            ?>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('title')); ?>">Title:</label>
                <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>"
                       name="<?php echo esc_attr($this->get_field_name('title')); ?>"
                       type="text" value="<?php echo esc_attr($title); ?>">
            </p>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('message')); ?>">Message:</label>
                <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('message')); ?>"
                          name="<?php echo esc_attr($this->get_field_name('message')); ?>"><?php echo esc_textarea($message); ?></textarea>
            </p>
            <?php
        }

        
        public function update($new_instance, $old_instance) {
            $instance = array();
            $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
            $instance['message'] = (!empty($new_instance['message'])) ? sanitize_textarea_field($new_instance['message']) : '';
            return $instance;
        }
    }
}

if (!function_exists('register_articleblogup_theme_widget')) {
    function register_articleblogup_theme_widget() {
        register_widget('articleblogup_Theme_Widget');
    }
}
add_action('widgets_init', 'register_articleblogup_theme_widget');
?>


