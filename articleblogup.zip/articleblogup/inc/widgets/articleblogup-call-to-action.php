<?php

class Articleblogup_Call_To_Action extends WP_Widget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {
        $widget_ops = array( 
            'classname'     => 'Articleblogup_call_to_action',
            'description'   => __( 'Display content as Call To Action.', 'Articleblogup' )
        );
        parent::__construct( 'Articleblogup_call_to_action', __( 'Articleblogup : Call To Action', 'Articleblogup' ), $widget_ops );
    }

    /**
     * Helper function that holds widget fields
     * Array is used in update and form functions
     */
    private function widget_fields() {

        $fields = array(
    
            'section_bg_image' => array(
                'Articleblogup_widgets_name'        => 'section_bg_image',
                'Articleblogup_widgets_title'       => __( 'Section Background Image', 'Articleblogup' ),
                'Articleblogup_widgets_field_type'  => 'upload',
            ),

            'section_content' => array(
                'Articleblogup_widgets_name'         => 'section_content',
                'Articleblogup_widgets_title'        => __( 'Section Content', 'Articleblogup' ),
                'Articleblogup_widgets_row'          => 5,
                'Articleblogup_widgets_field_type'   => 'textarea'
            ),

            'section_btn_text' => array(
                'Articleblogup_widgets_name'         => 'section_btn_text',
                'Articleblogup_widgets_title'        => __( 'Section Button Text', 'Articleblogup' ),
                'Articleblogup_widgets_field_type'   => 'text'
            ),

            'section_btn_url' => array(
                'Articleblogup_widgets_name'         => 'section_btn_url',
                'Articleblogup_widgets_title'        => __( 'Section Button URL', 'Articleblogup' ),
                'Articleblogup_widgets_field_type'   => 'url'
            )
        );
        return $fields;
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        extract( $args );
        if( empty( $instance ) ) {
            return ;
        }

        $Articleblogup_section_bg_image   = empty( $instance['section_bg_image'] ) ? '' : $instance['section_bg_image'];
        $Articleblogup_section_content    = empty( $instance['section_content'] ) ? '' : $instance['section_content'];
        $Articleblogup_section_btn_text   = empty( $instance['section_btn_text'] ) ? '' : $instance['section_btn_text'];
        $Articleblogup_section_btn_url    = empty( $instance['section_btn_url'] ) ? '' : $instance['section_btn_url'];

        echo $before_widget;
    ?>
            <div class="section-wrapper Articleblogup-widget-wrapper" style="background-image:url('<?php echo esc_url( $Articleblogup_section_bg_image ); ?>'); background-position: center; background-attachment: fixed; background-size: cover;">
                <div class="mt-container">
                    <div class="cta-content-wrapper">
                        <div class="cta-content"><?php echo wp_kses_post( $Articleblogup_section_content ); ?></div>
                        <?php if( !empty( $Articleblogup_section_btn_text ) ) { ?>
                            <div class="cta-btn-wrap">
                                <a href="<?php echo esc_url( $Articleblogup_section_btn_url ); ?>" class="cta-btn"><?php echo esc_html( $Articleblogup_section_btn_text ); ?></a>
                            </div>
                        <?php } ?>
                    </div>
                </div><!-- .mt-container -->
            </div><!-- .section-wrapper -->
    <?php
        echo $after_widget;
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param   array   $new_instance   Values just sent to be saved.
     * @param   array   $old_instance   Previously saved values from database.
     *
     * @return  array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        $widget_fields = $this->widget_fields();

        // Loop through fields
        foreach ( $widget_fields as $widget_field ) {

            extract( $widget_field );

            // Use helper function to get updated field values
            $instance[$Articleblogup_widgets_name] = sanitize_text_field( $new_instance[$Articleblogup_widgets_name] );
        }

        return $instance;
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param   array $instance Previously saved values from database.
     */
    public function form( $instance ) {
        $widget_fields = $this->widget_fields();

        // Loop through fields
        foreach ( $widget_fields as $widget_field ) {

            // Make array elements available as variables
            extract( $widget_field );
            $Articleblogup_widgets_field_value = !empty( $instance[$Articleblogup_widgets_name] ) ? esc_html( $instance[$Articleblogup_widgets_name] ) : '';
            ?>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( $Articleblogup_widgets_name ) ); ?>"><?php echo esc_html( $Articleblogup_widgets_title ); ?>:</label>
                <?php if ($Articleblogup_widgets_field_type == 'textarea') : ?>
                    <textarea class="widefat" rows="<?php echo intval( $Articleblogup_widgets_row ); ?>" id="<?php echo esc_attr( $this->get_field_id( $Articleblogup_widgets_name ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( $Articleblogup_widgets_name ) ); ?>"><?php echo esc_textarea( $Articleblogup_widgets_field_value ); ?></textarea>
                <?php else : ?>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( $Articleblogup_widgets_name ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( $Articleblogup_widgets_name ) ); ?>" type="<?php echo esc_attr( $Articleblogup_widgets_field_type ); ?>" value="<?php echo esc_attr( $Articleblogup_widgets_field_value ); ?>" />
                <?php endif; ?>
            </p>
            <?php
        }
    }
}

// Register widget
function register_Articleblogup_call_to_action_widget() {
    register_widget( 'Articleblogup_Call_To_Action' );
}

add_action( 'widgets_init', 'register_Articleblogup_call_to_action_widget' );
?>
