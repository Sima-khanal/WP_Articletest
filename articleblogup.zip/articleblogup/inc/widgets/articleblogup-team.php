<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Articleblogup_Team_Widget extends WP_Widget {
    public function __construct() {
        $widget_ops = array(
            'classname'   => 'articleblogup_team_widget',
            'description' => __('Display a team member with image, name, info, and a read more button.', 'Articleblogup')
        );
        parent::__construct('articleblogup_team_widget', __('Articleblogup: Team Member', 'Articleblogup'), $widget_ops);
    }

    // Widget Form Fields
    public function form($instance) {
        $defaults = array(
            'team_image' => '',
            'team_name' => '',
            'team_info' => '',
            'read_more_link' => ''
        );
        $instance = wp_parse_args((array) $instance, $defaults);

        $team_image = esc_url($instance['team_image']);
        $team_name = esc_attr($instance['team_name']);
        $team_info = esc_textarea($instance['team_info']);
        $read_more_link = esc_url($instance['read_more_link']);
        ?>

        <!-- Image Upload -->
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('team_image')); ?>">
                <?php esc_html_e('Upload Image:', 'Articleblogup'); ?>
            </label>
            <br>
            <input type="hidden" id="<?php echo esc_attr($this->get_field_id('team_image')); ?>"
                   name="<?php echo esc_attr($this->get_field_name('team_image')); ?>"
                   value="<?php echo $team_image; ?>">
            <button class="button button-primary articleblogup_upload_image"><?php esc_html_e('Upload Image', 'Articleblogup'); ?></button>
            <br>
            <img src="<?php echo esc_url($team_image); ?>" style="max-width:100%; margin-top:10px; display:<?php echo ($team_image) ? 'block' : 'none'; ?>;">
        </p>

        <!-- Team Name -->
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('team_name')); ?>">
                <?php esc_html_e('Name:', 'Articleblogup'); ?>
            </label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('team_name')); ?>"
                   name="<?php echo esc_attr($this->get_field_name('team_name')); ?>"
                   type="text" value="<?php echo $team_name; ?>">
        </p>

        <!-- Team Info -->
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('team_info')); ?>">
                <?php esc_html_e('Information:', 'Articleblogup'); ?>
            </label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('team_info')); ?>"
                      name="<?php echo esc_attr($this->get_field_name('team_info')); ?>" rows="4"><?php echo $team_info; ?></textarea>
        </p>

        <!-- Read More Link -->
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('read_more_link')); ?>">
                <?php esc_html_e('Read More URL (Optional):', 'Articleblogup'); ?>
            </label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('read_more_link')); ?>"
                   name="<?php echo esc_attr($this->get_field_name('read_more_link')); ?>"
                   type="url" value="<?php echo $read_more_link; ?>">
        </p>
           <script>
            jQuery(document).ready(function($) {
                function uploadImage(btn) {
                    var mediaUploader;
                    btn.on('click', function(e) {
                        e.preventDefault();
                        var button = $(this);
                        var field = button.prev(); // Hidden input field
                        var preview = button.next(); // Image preview
                        
                        // Open WordPress Media Uploader
                        mediaUploader = wp.media({
                            title: 'Select Image',
                            button: { text: 'Use this image' },
                            multiple: false
                        }).on('select', function() {
                            var attachment = mediaUploader.state().get('selection').first().toJSON();
                            field.val(attachment.url); // Set image URL in the hidden input
                            preview.attr('src', attachment.url).show(); // Show preview image
                        });

                        mediaUploader.open();
                    });
                }
                uploadImage($('.articleblogup_upload_image'));
            });
        </script>
        <?php
    }

    // Update Widget Fields
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['team_image'] = (!empty($new_instance['team_image'])) ? esc_url($new_instance['team_image']) : '';
        $instance['team_name'] = (!empty($new_instance['team_name'])) ? sanitize_text_field($new_instance['team_name']) : '';
        $instance['team_info'] = (!empty($new_instance['team_info'])) ? wp_kses_post($new_instance['team_info']) : '';
        $instance['read_more_link'] = (!empty($new_instance['read_more_link'])) ? esc_url($new_instance['read_more_link']) : '';

        return $instance;
    }

    // Display Widget Content
    public function widget($args, $instance) {
        extract($args);

        if (empty($instance)) {
            return;
        }

        $team_image = isset($instance['team_image']) ? esc_url($instance['team_image']) : '';
        $team_name = isset($instance['team_name']) ? esc_html($instance['team_name']) : '';
        $team_info = isset($instance['team_info']) ? esc_html($instance['team_info']) : '';
        $read_more_link = isset($instance['read_more_link']) ? esc_url($instance['read_more_link']) : '';

        echo $before_widget;
        ?>
        <div class="team-widget">
            <?php if ($team_image) : ?>
                <img src="<?php echo $team_image; ?>" alt="<?php echo esc_attr($team_name); ?>" class="team-image">
            <?php endif; ?>

            <?php if ($team_name) : ?>
                <h3 class="team-name"><?php echo $team_name; ?></h3>
            <?php endif; ?>

            <?php if ($team_info) : ?>
                <p class="team-info"><?php echo $team_info; ?></p>
            <?php endif; ?>

            <?php if ($read_more_link) : ?>
                <a href="<?php echo $read_more_link; ?>" class="team-read-more button"><?php esc_html_e('Read More', 'Articleblogup'); ?></a>
            <?php endif; ?>
        </div>

        <?php
        echo $after_widget;
    }
}

// Register the Widget
function register_Articleblogup_Team_Widget() {
    register_widget('Articleblogup_Team_Widget');
}
add_action('widgets_init', 'register_Articleblogup_Team_Widget');
?>
