<?php

function articletheme_customize_register( $wp_customize ) {
   
    $wp_customize->add_panel('articleblogup_contact', array(
        'title' => __('Footer Settings', 'articleblogup'),
        'priority' => 105,
    ));

    $wp_customize->add_section('articletheme_contact_section', array(
        'title'    => __('Contact Information', 'articletheme'),
        'panel' => 'articleblogup_contact',
        'priority' => 30,
    ));

    $wp_customize->add_setting('articletheme_location', array(
        'default'           => 'Santinagar, Kathmandu',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('articletheme_location', array(
        'label'   => __('Location', 'articletheme'),
        'section' => 'articletheme_contact_section',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('articletheme_email', array(
        'default'           => 'seemakhanal@gmail.com',
        'sanitize_callback' => 'sanitize_email',
    ));

    $wp_customize->add_control('articletheme_email', array(
        'label'   => __('Email', 'articletheme'),
        'section' => 'articletheme_contact_section',
        'type'    => 'email',
    ));

    $wp_customize->add_setting('articletheme_phone', array(
        'default'           => '982390068*',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('articletheme_phone', array(
        'label'   => __('Phone Number', 'articletheme'),
        'section' => 'articletheme_contact_section',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('articletheme_owner', array(
        'default'           => 'Owner',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('articletheme_owner', array(
        'label'   => __('Owner', 'articletheme'),
        'section' => 'articletheme_contact_section',
        'type'    => 'text',
    ));

    $wp_customize->add_section('articletheme_sidebar_section', array(
        'title'    => __('Sidebar Customization', 'articletheme'),
        'priority' => 40,
        'panel' => 'articleblogup_contact',
    ));

    $social_media = array('facebook', 'twitter', 'instagram');

    foreach ($social_media as $network) {
        $wp_customize->add_setting("{$network}_url", array(
            'default' => '',
            'sanitize_callback' => 'esc_url_raw',
        ));

        $wp_customize->add_control("{$network}_url", array(
            'label'   => __(ucfirst($network) . ' URL', 'articletheme'),
            'section' => 'articletheme_sidebar_section',
            'type'    => 'url',
        ));
    }

    $wp_customize->add_setting('theme_description_text', array(
        'default'           => get_bloginfo('description'),
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('theme_description_text', array(
        'label'   => __('Theme Description', 'articletheme'),
        'section' => 'articletheme_sidebar_section',
        'type'    => 'textarea',
    ));

    $wp_customize->add_panel('articleblogup_portfolio_panel', array(
        'title'    => __('Portfolio Settings', 'articleblogup'),
        'priority' => 32,
    ));

    $wp_customize->add_section('articleblogup_portfolio_section', array(
        'title'    => __('Portfolio Settings', 'articleblogup'),
        'priority' => 31,
        'panel'    => 'articleblogup_portfolio_panel',
    ));

    // Portfolio Title
    $wp_customize->add_setting('articleblogup_portfolio_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('articleblogup_portfolio_title', array(
        'label'   => __('Section Title', 'articleblogup'),
        'section' => 'articleblogup_portfolio_section',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('articleblogup_portfolio_info', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));

    $wp_customize->add_control('articleblogup_portfolio_info', array(
        'label'   => __('Section Info', 'articleblogup'),
        'section' => 'articleblogup_portfolio_section',
        'type'    => 'textarea',
    ));

    $wp_customize->add_setting('articleblogup_portfolio_category', array(
        'default'           => '',
        'sanitize_callback' => 'absint',
    ));

    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'articleblogup_portfolio_category', array(
        'label'    => __('Portfolio Category', 'articleblogup'),
        'section'  => 'articleblogup_portfolio_section',
        'type'     => 'select',
        'choices'  => articleblogup_get_categories(), 
    )));

    $wp_customize->add_setting('articleblogup_portfolio_post_count', array(
        'default'           => 3,
        'sanitize_callback' => 'articleblogup_sanitize_post_count',
    ));

    $wp_customize->add_control('articleblogup_portfolio_post_count', array(
        'label'   => __('Post Count', 'articleblogup'),
        'section' => 'articleblogup_portfolio_section',
        'type'    => 'number',
        'input_attrs' => array('min' => 1),
    ));


    $wp_customize->add_setting('footer_bg_color', array(
        'default'   => '#222',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color'
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer_bg_color_control', array(
        'label'    => __('Footer Background Color', 'articleblogup'),
        'section'  => 'footer_section',
        'settings' => 'footer_bg_color',
    )));

    $wp_customize->add_setting('footer_text_color', array(
        'default'   => '#ffffff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color'
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer_text_color_control', array(
        'label'    => __('Footer Text Color', 'articleblogup'),
        'section'  => 'footer_section',
        'settings' => 'footer_text_color',
    )));

    $wp_customize->add_setting('footer_copyright_text', array(
        'default'   => '&copy; ' . date('Y') . ' ' . get_bloginfo('name') . '. All rights reserved.',
        'sanitize_callback' => 'wp_kses_post'
    ));

    $wp_customize->add_control('footer_copyright_text_control', array(
        'label'    => __('Footer Copyright Text', 'articleblogup'),
        'section'  => 'footer_section',
        'settings' => 'footer_copyright_text',
        'type'     => 'textarea',
    ));

    $wp_customize->add_section('footer_section', array(
        'title'    => __('Footer Settings', 'articleblogup'),
        'priority' => 130,
    ));

}

add_action('customize_register', 'articletheme_customize_register');

function articleblogup_get_categories() {
    $categories = get_categories(array('hide_empty' => false));
    $choices = array();

    foreach ($categories as $category) {
        $choices[$category->term_id] = $category->name;
    }

    return $choices;
}

function articleblogup_sanitize_post_count($input) {
    return (is_numeric($input) && $input > 0) ? intval($input) : 3;
}