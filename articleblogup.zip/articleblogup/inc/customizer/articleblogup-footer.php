<?php

function articleblogup_footer_customizer($wp_customize) {

    $wp_customize->add_setting('footer_bg_color', array(
        'default'   => '#222',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color'
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer_bg_color_control', array(
        'label'    => __('Footer Background Color', 'articleblogup'),
        'section'  => 'footer_section',
        'settings' => 'footer_bg_color',
    )));

    $wp_customize->add_setting('footer_text_color', array(
        'default'   => '#ffffff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color'
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer_text_color_control', array(
        'label'    => __('Footer Text Color', 'articleblogup'),
        'section'  => 'footer_section',
        'settings' => 'footer_text_color',
    )));

    $wp_customize->add_setting('footer_copyright_text', array(
        'default'   => '&copy; ' . date('Y') . ' ' . get_bloginfo('name') . '. All rights reserved.',
        'sanitize_callback' => 'wp_kses_post'
    ));

    $wp_customize->add_control('footer_copyright_text_control', array(
        'label'    => __('Footer Copyright Text', 'articleblogup'),
        'section'  => 'footer_section',
        'settings' => 'footer_copyright_text',
        'type'     => 'textarea',
    ));

    $wp_customize->add_section('footer_section', array(
        'title'    => __('Footer Settings', 'articleblogup'),
        'priority' => 130,
    ));
}
add_action('customize_register', 'articleblogup_footer_customizer');

?>