<?php
/**
 * The footer for the theme
 *
 * @package articleBlogup
 */
?>

<footer id="colophon" class="site-footer">

    <div class="container">
        <h3>Contact Information</h3>
        <p><strong>Location:</strong> <?php echo esc_html(get_theme_mod('articletheme_location', 'Santinagar, Kathmandu')); ?></p>
        <p><strong>Email:</strong> <a href="mailto:<?php echo esc_attr(get_theme_mod('articletheme_email', 'seemakhanal@gmail.com')); ?>">
            <?php echo esc_html(get_theme_mod('articletheme_email', 'seemakhanal@gmail.com')); ?>
        </a></p>
        <p><strong>Phone:</strong> <?php echo esc_html(get_theme_mod('articletheme_phone', '982390068*')); ?></p>
        <p><strong>Owner:</strong> <?php echo esc_html(get_theme_mod('articletheme_owner', 'Owner')); ?></p>
    </div>

    <div class="footer-widgets">
    <div class="footer-widget-area">
        <?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
            <div class="widget-area">
                <?php dynamic_sidebar( 'footer-1' ); ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="footer-info" style="background: <?php echo get_theme_mod('footer_bg_color', '#222'); ?>; color: <?php echo get_theme_mod('footer_text_color', '#ffffff'); ?>;">
    <div class="footer-container">
        <div class="site-info">
            <p><?php echo get_theme_mod('footer_copyright_text', '&copy; ' . date('Y') . ' ' . get_bloginfo('name') . '. All rights reserved.'); ?></p>
            <p>Designed by <a href="https://www.articleblogup.com" style="color: <?php echo get_theme_mod('footer_text_color', '#ffffff'); ?>;">ArticleBlogup</a></p>
        </div>
    </div>
</div>
</footer>
<script>
	jQuery(document).ready(function($) {
    $('#category-select').change(function() {
        var selectedCategory = $(this).val();
        if (selectedCategory != 'all') {
            window.location.href = '?category=' + selectedCategory;  
        } else {
            window.location.href = ''; 
        }
    });
});

</script>


<?php wp_footer(); ?>
</body>
</html>
