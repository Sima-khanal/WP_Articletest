<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package articletest
 */

?>

	<footer id="colophon" class="site-footer">
		<div class="footer-info" style="background: <?php echo get_theme_mod('footer_bg_color', '#222'); ?>; color: <?php echo get_theme_mod('footer_text_color', '#ffffff'); ?>;">
    <div class="footer-container">
        <div class="site-info">
            <p><?php echo get_theme_mod('footer_copyright_text', '&copy; ' . date('Y') . ' ' . get_bloginfo('name') . '. All rights reserved.'); ?></p>
            <p>Designed by <a href="https://www.mysterythemes.com" style="color: <?php echo get_theme_mod('footer_text_color', '#ffffff'); ?>;">Mystery Themes</a></p>
        </div>
        <div class="site-info">
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'articletest' ) ); ?>">
				<?php
				/* translators: %s: CMS name, i.e. WordPress. */
				printf( esc_html__( 'Proudly powered by %s', 'articletest' ), 'WordPress' );
				?>
			</a>
			<span class="sep"> | </span>
				<?php
				/* translators: 1: Theme name, 2: Theme author. */
				printf( esc_html__( 'Theme: %1$s by %2$s.', 'articletest' ), 'articletest', '<a href="http://underscores.me/">Underscores.me</a>' );
				?>
		</div><!-- .site-info -->
    </div>
</div>

		
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
