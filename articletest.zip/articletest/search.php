<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package articletest
 */

get_header();
?>


	</main><!-- #main -->

<?php
get_sidebar();
get_footer();
