<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package articletest
 */

get_header();
?>
<?php
	// Get the customizer settings
	$banner_bg_image = get_theme_mod('articletest_banner_bg_image');
	$banner_header = get_theme_mod('articletest_banner_header', 'Welcome to My Website'); 
	$banner_description = get_theme_mod('articletest_banner_description', 'Your gateway to an amazing experience.'); 
	$banner_button_text = get_theme_mod('articletest_banner_button_text', 'Read More'); 
	$banner_button_link = get_theme_mod('articletest_banner_button_link', '#'); 
?>

<!-- Banner Section -->
<div class="articletest-banner" style="background-image: url('<?php echo esc_url($banner_bg_image); ?>');">
    <div class="articletest-banner-content">
        <h1><?php echo esc_html($banner_header); ?></h1>
        <p><?php echo esc_html($banner_description); ?></p>
        <a href="<?php echo esc_url($banner_button_link); ?>" class="articletest-banner-button"><?php echo esc_html($banner_button_text); ?></a>
    </div>
</div>

<!-- Gallery Container -->
<section class="articletest-containers">
    <?php for ($i = 1; $i <= 3; $i++): ?>
        <div class="articletest-container" style="background-image: url('<?php echo esc_url(get_theme_mod("container_{$i}_bg", '')); ?>');">
            <h2><?php echo esc_html(get_theme_mod("container_{$i}_header", "Container $i Header")); ?></h2>
        </div>
    <?php endfor; ?>
</section>

<!-- Featured Items -->
<section id="featured-slider">
    <h2> Featured Post</h2>

    <?php
    $category_filter = get_theme_mod('featured_posts_category', 'random');
    $args = array(
        'post_type'      => 'post',
        'posts_per_page' => -1,
        'orderby'        => ($category_filter === 'random') ? 'rand' : 'date',
    );

    if ($category_filter !== 'random') {
        $args['category_name'] = $category_filter;
    }

    $query = new WP_Query($args);
    ?>

    <div class="featured-container"> 
        <div class="featured-carousel-wrapper">
            <div class="featured-carousel">
                <?php if ($query->have_posts()) : ?>
                    <?php for ($i = 0; $i < 3; $i++) : ?>
                        <?php if ($query->have_posts()) : $query->the_post();
                            $bgImage = get_the_post_thumbnail_url(get_the_ID(), 'large');
                        ?>
                        <div class="featured-item" style="background-image: url('<?php echo esc_url($bgImage); ?>');">
                            <div class="overlay"></div>
                            <div class="content">
                                <span class="category"><?php the_category(', '); ?></span>
                                <h3><?php the_title(); ?></h3>
                                <p><?php echo wp_trim_words(get_the_content(), 15, '...'); ?></p>
                                <a href="<?php the_permalink(); ?>" class="read-more">Read More</a>
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php endfor; ?>
                <?php else : ?>
                    <p>No featured posts found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>


<div class="articletest-CTA-section">
    <h2><?php echo get_theme_mod('articletest_looking_for_more_header', 'Looking For More Posts?'); ?></h2>
    <p><?php echo get_theme_mod('articletest_get_our_latest_book', 'Get our latest book.'); ?></p>
    
    <!-- Mail field with subscribe button -->
    <form action="your-mail-subscription-handler-url" method="POST">
        <input type="email" name="email" placeholder="Enter your email" required>
        <button type="submit"><?php echo get_theme_mod('articletest_subscribe_button_text', 'Subscribe'); ?></button>
    </form>

    <!-- Privacy policy text -->
    <p class="privacy-policy-text"><?php echo get_theme_mod('articletest_privacy_policy_text', 'By submitting above, you agree to our privacy policy.'); ?></p>
</div>

<section id="recent-posts">
  <h2>Recent Collection</h2>
  <div class="posts-container"> 
    <?php
      $args = array(
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC',
        'posts_per_page' => -1,
      );
      $selected_category = get_theme_mod('recent_posts_category', 'all');
      if ($selected_category !== 'all') {
          $args['category_name'] = $selected_category;
      }
      $recent_posts = new WP_Query($args);
      if ($recent_posts->have_posts()) :
        while ($recent_posts->have_posts()) : $recent_posts->the_post();
    ?>
    <div class="post-item">
      <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>">
      <div class="post-meta">
        <span class="category"><?php the_category(', '); ?></span> 
      </div>
      <h3><?php the_title(); ?></h3>
      <p><?php echo wp_trim_words(get_the_content(), 15, '...'); ?></p>
      <a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>
    </div>
    <?php endwhile; endif; wp_reset_postdata(); ?>
  </div>
</section>
	</main><!-- #main -->
<?php
get_sidebar();
get_footer();
