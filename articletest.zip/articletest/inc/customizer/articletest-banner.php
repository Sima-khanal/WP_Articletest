<?php

if (!function_exists('articletest_banner_customize_register')) {
    function articletest_banner_customize_register( $wp_customize ) {
        
        // Add Banner Settings Section
        $wp_customize->add_section('articletest_banner_section', array(
            'title'    => __('Articletest Banner', 'articletest'),
            'priority' => 30,
        ));

        // Banner Background Image
        $wp_customize->add_setting('articletest_banner_bg_image', array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ));
        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'articletest_banner_bg_image', array(
            'label'    => __('Background Image', 'articletest'),
            'section'  => 'articletest_banner_section',
            'settings' => 'articletest_banner_bg_image',
        )));

        // Banner Header Text
        $wp_customize->add_setting('articletest_banner_header', array(
            'default'           => 'Welcome to My Website',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('articletest_banner_header', array(
            'label'    => __('Banner Header Text', 'articletest'),
            'section'  => 'articletest_banner_section',
            'type'     => 'text',
        ));

        // Banner Description Text
        $wp_customize->add_setting('articletest_banner_description', array(
            'default'           => 'Your gateway to an amazing experience.',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('articletest_banner_description', array(
            'label'    => __('Banner Description', 'articletest'),
            'section'  => 'articletest_banner_section',
            'type'     => 'textarea',
        ));

        // Banner Button Text
        $wp_customize->add_setting('articletest_banner_button_text', array(
            'default'           => 'Read More',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('articletest_banner_button_text', array(
            'label'    => __('Button Text', 'articletest'),
            'section'  => 'articletest_banner_section',
            'type'     => 'text',
        ));

        // Banner Button Link
        $wp_customize->add_setting('articletest_banner_button_link', array(
            'default'           => '#',
            'sanitize_callback' => 'esc_url_raw',
        ));
        $wp_customize->add_control('articletest_banner_button_link', array(
            'label'    => __('Button Link', 'articletest'),
            'section'  => 'articletest_banner_section',
            'type'     => 'url',
        ));
    }

    add_action('customize_register', 'articletest_banner_customize_register');
}
