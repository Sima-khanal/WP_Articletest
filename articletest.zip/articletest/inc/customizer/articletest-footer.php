<?php
if (!function_exists('articletest_footer_customizer')) {
    function articletest_footer_customizer($wp_customize)
    {
        $wp_customize->add_section('footer_section', array(
            'title'    => __('Footer Settings', 'articletest'),
            'priority' => 30,
        ));

        // Footer Background Color
        $wp_customize->add_setting('footer_bg_color', array(
            'default'   => '#222',
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_hex_color',
        ));

        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer_bg_color_control', array(
            'label'    => __('Footer Background Color', 'articletest'),
            'section'  => 'footer_section',
            'settings' => 'footer_bg_color',
        )));

        // Footer Text Color
        $wp_customize->add_setting('footer_text_color', array(
            'default'   => '#ffffff',
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_hex_color',
        ));

        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer_text_color_control', array(
            'label'    => __('Footer Text Color', 'articletest'),
            'section'  => 'footer_section',
            'settings' => 'footer_text_color',
        )));

        // Footer Copyright Text
        $wp_customize->add_setting('footer_copyright_text', array(
            'default'   => '&copy; ' . date('Y') . ' ' . get_bloginfo('name') . '. All rights reserved.',
            'transport' => 'refresh',
            'sanitize_callback' => 'wp_kses_post',
        ));

        $wp_customize->add_control('footer_copyright_text_control', array(
            'label'    => __('Footer Copyright Text', 'articletest'),
            'type'     => 'textarea',
            'section'  => 'footer_section',
            'settings' => 'footer_copyright_text',
        ));
    }
    add_action('customize_register', 'articletest_footer_customizer');
}

function articletest_footer_live_preview()
{
    wp_enqueue_script('customizer-live-preview', get_template_directory_uri() . '/js/customizer.js', array('jquery', 'customize-preview'), '', true);
}
add_action('customize_preview_init', 'articletest_footer_live_preview');
?>
