<?php
if(!function_exists('articletest_cta_section')){
function articletest_cta_section($wp_customize) {
     $wp_customize->add_panel('articletest_CTA', array(
            'title'    => __('CTA Customization', 'articletest'),
            'priority' => 31,
        ));
    
        $wp_customize->add_section('articletest_cta_section', array(
            'title' => __('CTA Section', 'articletest'),
            'priority' => 30,
            'panel' => 'articletest_CTA',
        ));

        $wp_customize->add_setting('articletest_header', array(
            'default' => 'Looking For More Posts?',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('articletest__header', array(
            'label' => __('Header Text', 'articletest'),
            'section' => 'articletest_cta_section',
            'settings' => 'articletest_header',
            'type' => 'text',
        ));

        $wp_customize->add_setting('articletest_description', array(
            'default' => 'Get our latest book.',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('articletest_description', array(
            'label' => __('Paragraph Text', 'articletest'),
            'section' => 'articletest_cta_section',
            'settings' => 'articletest_description',
            'type' => 'text',
        ));

        $wp_customize->add_setting('articletest_button_text', array(
            'default' => 'Subscribe',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('articletest_button_text', array(
            'label' => __('Button Text', 'articletest'),
            'section' => 'articletest_cta_section',
            'settings' => 'articletest_button_text',
            'type' => 'text',
        ));

        $wp_customize->add_setting('articletest_text', array(
            'default' => 'By submitting above, you agree to our privacy policy.',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('articletest_text', array(
            'label' => __('Privacy Policy Text', 'articletest'),
            'section' => 'articletest_cta_section',
            'settings' => 'articletest_text',
            'type' => 'text',
        ));
}

add_action('customize_register', 'articletest_cta_section');
}