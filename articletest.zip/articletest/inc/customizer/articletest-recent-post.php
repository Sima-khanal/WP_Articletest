<?php
function articletest_recent_post($wp_customize) {
    $wp_customize->add_section('recent_posts_section', array(
        'title'    => __('Recent Posts Settings', 'articletest'),
        'priority' => 35,
    ));

    $categories = get_categories();
    $category_options = array('all' => __('All Categories', 'articletest'));

    foreach ($categories as $category) {
        $category_options[$category->slug] = $category->name;
    }

    $wp_customize->add_setting('recent_posts_category', array(
        'default'   => 'all',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('recent_posts_category', array(
        'label'    => __('Select Category for Recent Posts', 'articletest'),
        'section'  => 'recent_posts_section',
        'settings' => 'recent_posts_category',
        'type'     => 'select',
        'choices'  => $category_options,
    ));
}

add_action('customize_register', 'articletest_recent_post');
