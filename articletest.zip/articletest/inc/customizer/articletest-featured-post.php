<?php
function articletest_customize_featured_post($wp_customize) {
    // Add a section for Featured Posts settings
    $wp_customize->add_section('featured_posts_section', array(
        'title'    => __('Featured Posts Settings', 'articletest'),
        'priority' => 30,
    ));

    // Get all categories dynamically
    $categories = get_categories();
    $category_options = array('random' => __('Random Posts', 'articletest'));
    
    foreach ($categories as $category) {
        $category_options[$category->slug] = $category->name;
    }

    // Add setting for the category selection
    $wp_customize->add_setting('featured_posts_category', array(
        'default'   => 'random',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('featured_posts_category', array(
        'label'    => __('Select Category for Featured Posts', 'articletest'),
        'section'  => 'featured_posts_section',
        'settings' => 'featured_posts_category',
        'type'     => 'select',
        'choices'  => $category_options,
    ));
}
add_action('customize_register', 'articletest_customize_featured_post');
