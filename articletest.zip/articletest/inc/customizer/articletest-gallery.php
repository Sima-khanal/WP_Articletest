<?php

if (!function_exists('articletest_custom_theme_customizer')) {
function articletest_custom_theme_customizer($wp_customize) {
   
    $wp_customize->add_panel('articletest_gallery', array(
        'title'    => __('Gallery Settings', 'articletest'),
        'priority' => 32,
    ));
    for ($i = 1; $i <= 3; $i++) {

        $wp_customize->add_section("container_{$i}_section", array(
            'title'    => __("Container $i Settings", "articletest"),
            'priority' => 30 + $i,
            'panel' => 'articletest_gallery',
        ));

        $wp_customize->add_setting("container_{$i}_bg", array(
            'default'   => '',
            'transport' => 'refresh',
            'sanitize_callback' => 'esc_url_raw'
        ));

        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "container_{$i}_bg", array(
            'label'    => __("Container $i Background Image", "articletest"),
            'section'  => "container_{$i}_section",
            'settings' => "container_{$i}_bg",
        )));

        $wp_customize->add_setting("container_{$i}_header", array(
            'default'   => "Container $i Header",
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_text_field'
        ));

        $wp_customize->add_control("container_{$i}_header", array(
            'label'    => __("Container $i Header Text", "articletest"),
            'section'  => "container_{$i}_section",
            'settings' => "container_{$i}_header",
            'type'     => 'text',
        ));
    }
}

add_action('customize_register', 'articletest_custom_theme_customizer');
}